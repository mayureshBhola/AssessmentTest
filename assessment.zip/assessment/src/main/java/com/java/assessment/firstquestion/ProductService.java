package com.java.assessment.firstquestion;

import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Component;

/**
 * This class will act as the Service that will provide the sort logic to the
 * Controller
 */
@Component
public class ProductService {


	public List<Product> sortProduct(List<Product> list) {
		// TODO Auto-generated method stub
		list.sort(Comparator.comparing(Product::getProductId).thenComparing(Product::getLaunchDate).reversed());
		return list;
	}

}
