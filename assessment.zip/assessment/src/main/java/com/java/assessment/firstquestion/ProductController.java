package com.java.assessment.firstquestion;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/**
 * This class will act as the Controller that will route the request to the
 * Service and return the sortedList of products as a response
 */

@RestController
public class ProductController {

	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	Map<String, List<Product>> response = new HashMap<String, List<Product>>();

	@Autowired
	ProductService service;

	@PostMapping("/sortProducts")
	public Map<String, List<Product>> sortProduct(@RequestBody Map<String, List<Product>> productmap) {
		try {
			logger.info("sortProduct will be triggered");
			response.put("sortedProductList", service.sortProduct(productmap.get("productList")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Controller Error", e);
		}
		return response;
	}

}
